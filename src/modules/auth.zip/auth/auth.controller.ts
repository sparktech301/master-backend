import { Body, Controller, Patch, Post, Req, UseGuards } from '@nestjs/common';
import { AuthService } from './auth.service';
import { RequestOtpDto } from './dto/request-otp.dto';
import { VerifyOtpDto } from './dto/verify-otp.dto';
import { CompleteProfileDto } from './dto/complete-profile.dto';

@Controller('auth')
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  @Post('request-otp')
  requestOtp(@Body() data:RequestOtpDto){
    return this.authService.requestOtp(data)
  }

  @Post('verify-otp')
  verifyOtp(@Body() data:VerifyOtpDto){
    return this.authService.verifyOtp(data)
  }

  @UseGuards()
  @Patch('complete-profile')
  completeProfile(
    @Body() data:CompleteProfileDto,
  ){
    return this.authService.completeProfile(data.userId,data)
  }
}
