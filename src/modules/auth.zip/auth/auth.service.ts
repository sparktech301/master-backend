import {
  BadRequestException,
  HttpException,
  HttpStatus,
  Injectable,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { PrismaService } from 'src/prisma/prisma.service';
import { RequestOtpDto } from './dto/request-otp.dto';
import {
  generateOtpCode,
  hashOtpCode,
  MAX_REQUESTS_PER_WINDOW,
  MAX_VERIFY_ATTEMPTS,
  OTP_EXPIRY_MINUTES,
  REQUEST_WINDOW_MINUTES,
} from './otp.util';
import { VerifyOtpDto } from './dto/verify-otp.dto';
import { create } from 'domain';
import { CompleteProfileDto } from './dto/complete-profile.dto';

const USER_SELECT = {
  id: true,
  phoneNumber: true,
  email: true,
  fullName: true,
  role: true,
  status: true,
  isPhoneVerification: true,
  createdAt: true,
  updatedAt: true,
} as const;

@Injectable()
export class AuthService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly jwtService: JwtService,
  ) {}

  async requestOtp(data: RequestOtpDto) {
    const windowStart = new Date(
      Date.now() - REQUEST_WINDOW_MINUTES * 60 * 1000,
    );

    const recentCount = await this.prisma.phoneOtp.count({
      where: {
        phoneNumber: data.phoneNumber,
        createdAt: {
          gte: windowStart,
        },
      },
    });

    if (recentCount >= MAX_REQUESTS_PER_WINDOW) {
      throw new HttpException(
        `Too many requests. Please try again after ${REQUEST_WINDOW_MINUTES} minutes`,
        HttpStatus.TOO_MANY_REQUESTS,
      );
    }

    const code = generateOtpCode();

    const expiresAt = new Date(Date.now() + OTP_EXPIRY_MINUTES * 60 * 1000);

    await this.prisma.phoneOtp.create({
      data: {
        phoneNumber: data.phoneNumber,
        code: hashOtpCode(code),
        expiresAt,
      },
    });

    console.log(`OTP for ${data.phoneNumber}: ${code}`);

    return {
      message: 'OTP sent successfully',
      phoneNumber: data.phoneNumber,
      expiresInSeconds: OTP_EXPIRY_MINUTES * 60,
      code
    };
  }

  async verifyOtp(data: VerifyOtpDto) {
    const otp = await this.prisma.phoneOtp.findFirst({
      where: {
        phoneNumber: data.phoneNumber,
        isUsed: false,
        expiresAt: {
          gt: new Date(),
        },
      },
      orderBy: {
        createdAt: 'desc',
      },
    });

    if (!otp) {
      throw new BadRequestException(
        'OTP expired or not requested. Please request a new one.',
      );
    }

    if (otp.attempts >= MAX_VERIFY_ATTEMPTS) {
      throw new BadRequestException(
        'Too many incorrect attempts. Please request a new OTP.',
      );
    }

    const isMatch = otp.code === hashOtpCode(data.code);

    if (!isMatch) {
      await this.prisma.phoneOtp.update({
        where: {
          id: otp.id,
        },

        data: {
          attempts: {
            increment: 1,
          },
        },
      });

      throw new BadRequestException('Invalid OTP');
    }

    const user = await this.prisma.$transaction(async (tx) => {
      await tx.phoneOtp.update({
        where: {
          id: otp.id,
        },
        data: {
          isUsed: true,
        },
      });

      return tx.user.upsert({
        where: {
          phoneNumber: data.phoneNumber,
        },
        update: {
          isPhoneVerification: true,
        },
        create: {
          phoneNumber: data.phoneNumber,
          isPhoneVerification: true,
        },
        select: USER_SELECT,
      });
    });

    const accessToken =await this.jwtService.signAsync({
      sub: user.id,
      phoneNumber: user.phoneNumber,
      role: user.role,
    });

    return {
      user,
      accessToken,
    };
  }

  async completeProfile(userid: string, data: CompleteProfileDto) {
    const user = await this.prisma.user.findUnique({
      where: {
        id: userid,
      },
    });

    if (!user) {
      throw new BadRequestException('User not found');
    }

    // if (user.isPhoneVerification) {
    //   throw new BadRequestException('Profile already completed');
    // }

    return this.prisma.user.update({
      where: {
        id: userid,
      },
      data: {
        fullName: data.fullName || user.fullName,
        email: data.email || user.email,
        role: data.role || user.role,
      },
      select: USER_SELECT,
    });
  }
}
